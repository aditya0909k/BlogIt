All of these files act as an export of our database to be graded for the Table Listing.
The record amounts were simply too great to be copy pasted into a Word Document.

NOTE: In Excel, we represent a SET as {<values>}. However, in SQL this is not allowed. So, we use a parsing script in Python to remove these when creating the database elements.

Thank you.